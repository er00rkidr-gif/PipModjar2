package com.pip;

import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;

import java.util.UUID;

public class PipEntity extends PathfinderMob {
    public enum Order { FOLLOW, STAY, WOOD, FISH }

    // ===== Tweak the horror pacing here (counted in nights since taming) =====
    static final int UNEASY_NIGHT = 2;     // stares at you now and then, eyes start to glow
    static final int DISOBEY_NIGHT = 3;    // head tilt, ignores ~40% of orders
    static final int MONSTER_NIGHT = 5;    // transforms, ignores ALL orders, never stops watching you
    static final float DISOBEY_CHANCE = 0.4f;

    private static final EntityDataAccessor<Boolean> MONSTER = SynchedEntityData.defineId(PipEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> STAGE = SynchedEntityData.defineId(PipEntity.class, EntityDataSerializers.INT);

    private UUID ownerUuid;
    private long tameDay = -1;
    private Order order = Order.FOLLOW;
    private int stareTicks;

    public PipEntity(EntityType<? extends PipEntity> type, Level level) {
        super(type, level);
        setPersistenceRequired();
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 10)
                .add(Attributes.MOVEMENT_SPEED, 0.32)
                .add(Attributes.ATTACK_DAMAGE, 2);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new FloatGoal(this));
        goalSelector.addGoal(1, new PipGoals.HauntGoal(this));
        goalSelector.addGoal(2, new PipGoals.GatherGoal(this));
        goalSelector.addGoal(3, new PipGoals.StayGoal(this));
        goalSelector.addGoal(4, new PipGoals.FollowGoal(this));
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        entityData.define(MONSTER, false);
        entityData.define(STAGE, 0);
    }

    // ---------- state ----------
    public boolean isMonster() { return entityData.get(MONSTER); }
    public int getStage() { return entityData.get(STAGE); }
    public Order getOrder() { return order; }
    public void setOrder(Order o) { order = o; getNavigation().stop(); }
    public boolean isOwner(Player p) { return ownerUuid != null && ownerUuid.equals(p.getUUID()); }
    public Player getOwner() { return ownerUuid == null ? null : level().getPlayerByUUID(ownerUuid); }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        return isMonster() ? EntityDimensions.fixed(0.9f, 2.2f) : super.getDimensions(pose);
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        if (key == MONSTER) refreshDimensions();
        super.onSyncedDataUpdated(key);
    }

    // ---------- taming / interaction ----------
    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (ownerUuid == null) {
            if (stack.is(Items.COD) || stack.is(Items.SALMON)) {
                if (!level().isClientSide) {
                    if (!player.getAbilities().instabuild) stack.shrink(1);
                    ownerUuid = player.getUUID();
                    tameDay = getServer().overworld().getDayTime() / 24000L;
                    ((ServerLevel) level()).sendParticles(ParticleTypes.HEART, getX(), getY() + 0.6, getZ(), 7, 0.3, 0.3, 0.3, 0.02);
                    playSound(SoundEvents.CAT_PURREOW, 1f, 1f);
                }
                return InteractionResult.sidedSuccess(level().isClientSide);
            }
            return InteractionResult.PASS;
        }
        if (isOwner(player) && !isMonster() && hand == InteractionHand.MAIN_HAND && stack.isEmpty()) {
            if (!level().isClientSide) setOrder(order == Order.STAY ? Order.FOLLOW : Order.STAY);
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        return InteractionResult.PASS;
    }

    /** Called by chat/voice. Pip answers (or doesn't) in its own way. */
    public void receiveOrder(Order o, ServerPlayer player) {
        if (isMonster()) {
            String[] lines = {"...", "Pip is watching you.", "It isn't listening.", "Pip tilts its head."};
            player.displayClientMessage(Component.literal(lines[random.nextInt(lines.length)])
                    .withStyle(ChatFormatting.DARK_RED, ChatFormatting.ITALIC), true);
            return;
        }
        if (getStage() >= 2 && random.nextFloat() < DISOBEY_CHANCE) {
            player.displayClientMessage(Component.literal("Pip just stares at you.")
                    .withStyle(ChatFormatting.GRAY, ChatFormatting.ITALIC), true);
            return;
        }
        setOrder(o);
        playSound(SoundEvents.CAT_AMBIENT, 1f, 1.2f);
        String reply = switch (o) {
            case WOOD -> "on it! (wood)";
            case FISH -> "on it! (fish)";
            case STAY -> "staying.";
            case FOLLOW -> "coming!";
        };
        player.displayClientMessage(Component.literal("Pip: " + reply), true);
    }

    // ---------- the creep factor ----------
    private void updateStage() {
        if (ownerUuid == null || tameDay < 0) return;
        long t = getServer().overworld().getDayTime();
        long nights = (t / 24000L - tameDay) + ((t % 24000L) >= 13000L ? 1 : 0);
        int stage = nights >= MONSTER_NIGHT ? 3 : nights >= DISOBEY_NIGHT ? 2 : nights >= UNEASY_NIGHT ? 1 : 0;
        if (stage != getStage()) {
            entityData.set(STAGE, stage);
            if (stage >= 3 && !isMonster()) {
                entityData.set(MONSTER, true);
                playSound(SoundEvents.ENDERMAN_SCREAM, 1.2f, 0.5f);
            }
        }
    }

    public void lookAtOwner(Player o) {
        double dx = o.getX() - getX(), dz = o.getZ() - getZ();
        float yaw = (float) (Mth.atan2(dz, dx) * 57.29578) - 90f;
        setYRot(yaw); setYBodyRot(yaw); setYHeadRot(yaw);
        getLookControl().setLookAt(o.getX(), o.getEyeY(), o.getZ());
    }

    public void snapNear(Player o) {
        moveTo(o.getX() + (random.nextDouble() - .5) * 4, o.getY(), o.getZ() + (random.nextDouble() - .5) * 4, getYRot(), getXRot());
        getNavigation().stop();
    }

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) return;
        if (tickCount % 20 == 0) updateStage();
        Player o = getOwner();
        if (o == null) return;
        int s = getStage();
        if (isMonster()) {
            lookAtOwner(o);
        } else if (s >= 1) {
            if (stareTicks > 0) { stareTicks--; lookAtOwner(o); }
            else if (random.nextInt(s == 1 ? 400 : 150) == 0) stareTicks = 40 + random.nextInt(60);
        }
    }

    // ---------- sounds ----------
    @Override protected SoundEvent getAmbientSound() { return isMonster() ? SoundEvents.CAT_HISS : SoundEvents.CAT_AMBIENT; }
    @Override protected SoundEvent getHurtSound(DamageSource s) { return SoundEvents.CAT_HURT; }
    @Override protected SoundEvent getDeathSound() { return SoundEvents.CAT_DEATH; }
    @Override public void playAmbientSound() {
        SoundEvent s = getAmbientSound();
        if (s != null) playSound(s, getSoundVolume(), isMonster() ? 0.4f : getVoicePitch());
    }

    // ---------- save/load ----------
    @Override public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        if (ownerUuid != null) tag.putUUID("Owner", ownerUuid);
        tag.putLong("TameDay", tameDay);
        tag.putString("Order", order.name());
    }
    @Override public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.hasUUID("Owner")) ownerUuid = tag.getUUID("Owner");
        tameDay = tag.contains("TameDay") ? tag.getLong("TameDay") : -1;
        try { order = Order.valueOf(tag.getString("Order")); } catch (Exception e) { order = Order.FOLLOW; }
    }
}
