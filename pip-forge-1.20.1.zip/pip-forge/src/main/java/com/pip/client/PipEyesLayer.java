package com.pip.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.pip.PipEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;

/** Fullbright glowing eyes: faint green from night 2, blazing red in monster form. */
public class PipEyesLayer extends RenderLayer<PipEntity, EntityModel<PipEntity>> {
    private static final ResourceLocation CAT_EYES = new ResourceLocation("pip", "textures/entity/pip_eyes.png");
    private static final ResourceLocation MON_EYES = new ResourceLocation("pip", "textures/entity/pip_monster_eyes.png");

    public PipEyesLayer(RenderLayerParent<PipEntity, EntityModel<PipEntity>> parent) { super(parent); }

    @Override
    public void render(PoseStack pose, MultiBufferSource buffers, int light, PipEntity e,
                       float limbSwing, float limbSwingAmount, float partialTick, float age, float netHeadYaw, float headPitch) {
        if (e.isInvisible() || (e.getStage() < 1 && !e.isMonster())) return;
        VertexConsumer vc = buffers.getBuffer(RenderType.eyes(e.isMonster() ? MON_EYES : CAT_EYES));
        getParentModel().renderToBuffer(pose, vc, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, 1f, 1f, 1f, 1f);
    }
}
