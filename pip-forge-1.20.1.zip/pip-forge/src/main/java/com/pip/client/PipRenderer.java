package com.pip.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.pip.PipEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class PipRenderer extends MobRenderer<PipEntity, EntityModel<PipEntity>> {
    private static final ResourceLocation CAT = new ResourceLocation("pip", "textures/entity/pip.png");
    private static final ResourceLocation MONSTER = new ResourceLocation("pip", "textures/entity/pip_monster.png");
    private final EntityModel<PipEntity> catModel;
    private final EntityModel<PipEntity> monsterModel;

    public PipRenderer(EntityRendererProvider.Context ctx) {
        super(ctx, new PipModel(ctx.bakeLayer(PipModel.LAYER)), 0.35f);
        this.catModel = this.model;
        this.monsterModel = new PipMonsterModel(ctx.bakeLayer(PipMonsterModel.LAYER));
        addLayer(new PipEyesLayer(this));
    }

    @Override
    public void render(PipEntity e, float yaw, float partialTick, PoseStack pose, MultiBufferSource buffers, int light) {
        this.model = e.isMonster() ? monsterModel : catModel;
        this.shadowRadius = e.isMonster() ? 0.6f : 0.35f;
        super.render(e, yaw, partialTick, pose, buffers, light);
    }

    @Override
    public ResourceLocation getTextureLocation(PipEntity e) { return e.isMonster() ? MONSTER : CAT; }
}
