package com.pip.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.pip.PipEntity;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

/** Cute little cat form (64x64 texture). */
public class PipModel extends EntityModel<PipEntity> {
    public static final ModelLayerLocation LAYER = new ModelLayerLocation(new ResourceLocation("pip", "pip"), "main");
    private final ModelPart root, head, tail, legFL, legFR, legBL, legBR;

    public PipModel(ModelPart root) {
        this.root = root;
        head = root.getChild("head"); tail = root.getChild("tail");
        legFL = root.getChild("leg_fl"); legFR = root.getChild("leg_fr");
        legBL = root.getChild("leg_bl"); legBR = root.getChild("leg_br");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition r = mesh.getRoot();
        r.addOrReplaceChild("body", CubeListBuilder.create().texOffs(0, 0).addBox(-2.5f, -2.5f, -5f, 5, 5, 10), PartPose.offset(0, 18, 0));
        PartDefinition head = r.addOrReplaceChild("head", CubeListBuilder.create().texOffs(32, 0).addBox(-2.5f, -2.5f, -4f, 5, 5, 4), PartPose.offset(0, 16, -5));
        head.addOrReplaceChild("ear_l", CubeListBuilder.create().texOffs(0, 28).addBox(-2.5f, -4.5f, -2f, 2, 2, 1), PartPose.ZERO);
        head.addOrReplaceChild("ear_r", CubeListBuilder.create().texOffs(8, 28).addBox(0.5f, -4.5f, -2f, 2, 2, 1), PartPose.ZERO);
        head.addOrReplaceChild("eye_l", CubeListBuilder.create().texOffs(52, 0).addBox(-2.2f, -1f, -4.02f, 2, 2, 0), PartPose.ZERO);
        head.addOrReplaceChild("eye_r", CubeListBuilder.create().texOffs(52, 4).addBox(0.2f, -1f, -4.02f, 2, 2, 0), PartPose.ZERO);
        r.addOrReplaceChild("leg_fl", CubeListBuilder.create().texOffs(0, 32).addBox(-1, 0, -1, 2, 5, 2), PartPose.offset(-1.5f, 19, -3));
        r.addOrReplaceChild("leg_fr", CubeListBuilder.create().texOffs(8, 32).addBox(-1, 0, -1, 2, 5, 2), PartPose.offset(1.5f, 19, -3));
        r.addOrReplaceChild("leg_bl", CubeListBuilder.create().texOffs(16, 32).addBox(-1, 0, -1, 2, 5, 2), PartPose.offset(-1.5f, 19, 3.5f));
        r.addOrReplaceChild("leg_br", CubeListBuilder.create().texOffs(24, 32).addBox(-1, 0, -1, 2, 5, 2), PartPose.offset(1.5f, 19, 3.5f));
        r.addOrReplaceChild("tail", CubeListBuilder.create().texOffs(0, 44).addBox(-1, -1, 0, 2, 2, 8), PartPose.offset(0, 16.5f, 5));
        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(PipEntity e, float limbSwing, float limbSwingAmount, float age, float netHeadYaw, float headPitch) {
        head.xRot = headPitch * ((float) Math.PI / 180F);
        head.yRot = netHeadYaw * ((float) Math.PI / 180F);
        head.zRot = e.getStage() >= 2 ? 0.35f : 0f;   // creepy head tilt once it starts turning
        float s = Mth.cos(limbSwing * 0.6662f) * 1.2f * limbSwingAmount;
        legFL.xRot = s; legBR.xRot = s;
        legFR.xRot = -s; legBL.xRot = -s;
        tail.xRot = 0.6f;
        tail.yRot = Mth.sin(age * 0.1f) * (e.getStage() >= 1 ? 0.05f : 0.25f);
    }

    @Override
    public void renderToBuffer(PoseStack pose, VertexConsumer vc, int light, int overlay, float r, float g, float b, float a) {
        root.render(pose, vc, light, overlay, r, g, b, a);
    }
}
