package com.pip;

import net.minecraft.server.level.ServerPlayer;
import java.util.List;
import java.util.Locale;

/** Parses "Pip, <order>" from chat or voice and hands it to the player's Pip(s). */
public final class PipCommands {
    private static final String[] NAMES = {"pip", "pipe", "pit", "pep", "pup"}; // voice mishears

    public static void handle(ServerPlayer player, String raw) {
        if (raw == null) return;
        String t = raw.toLowerCase(Locale.ROOT).trim();
        boolean addressed = false;
        for (String n : NAMES) if (t.startsWith(n) || t.contains(" " + n + " ") || t.contains(" " + n + ",")) addressed = true;
        if (!addressed) return;
        PipEntity.Order order = parse(t);
        if (order == null) return;
        List<PipEntity> pips = player.serverLevel().getEntitiesOfClass(PipEntity.class,
                player.getBoundingBox().inflate(48), p -> p.isOwner(player));
        for (PipEntity pip : pips) pip.receiveOrder(order, player);
    }

    private static PipEntity.Order parse(String t) {
        if (has(t, "wood", "log", "tree", "lumber")) return PipEntity.Order.WOOD;
        if (has(t, "fish", "cod", "salmon")) return PipEntity.Order.FISH;
        if (has(t, "stay", "sit", "wait", "stop")) return PipEntity.Order.STAY;
        if (has(t, "follow", "come", "here")) return PipEntity.Order.FOLLOW;
        return null;
    }

    private static boolean has(String t, String... words) {
        for (String w : words) if (t.contains(w)) return true;
        return false;
    }
}
