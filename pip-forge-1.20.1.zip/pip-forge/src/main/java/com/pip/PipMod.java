package com.pip;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.event.ServerChatEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(PipMod.ID)
public class PipMod {
    public static final String ID = "pip";

    public static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ID);
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, ID);

    public static final RegistryObject<EntityType<PipEntity>> PIP = ENTITIES.register("pip", () ->
            EntityType.Builder.of(PipEntity::new, MobCategory.CREATURE).sized(0.6f, 0.7f).clientTrackingRange(8).build("pip"));

    public static final RegistryObject<Item> PIP_SPAWN_EGG = ITEMS.register("pip_spawn_egg", () ->
            new ForgeSpawnEggItem(PIP, 0xE08A3C, 0x1A1A1A, new Item.Properties()));

    public PipMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ENTITIES.register(bus);
        ITEMS.register(bus);
        bus.addListener(this::attributes);
        bus.addListener(this::tabs);
        MinecraftForge.EVENT_BUS.addListener(this::onChat);
    }

    private void attributes(EntityAttributeCreationEvent e) {
        e.put(PIP.get(), PipEntity.createAttributes().build());
    }

    private void tabs(BuildCreativeModeTabContentsEvent e) {
        if (e.getTabKey() == CreativeModeTabs.SPAWN_EGGS) e.accept(PIP_SPAWN_EGG);
    }

    /** Typed commands: "Pip, gather some wood" */
    private void onChat(ServerChatEvent e) {
        PipCommands.handle(e.getPlayer(), e.getRawText());
    }
}
