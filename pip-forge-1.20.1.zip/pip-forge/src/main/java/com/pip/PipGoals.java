package com.pip;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.animal.AbstractFish;
import net.minecraft.world.entity.animal.Cod;
import net.minecraft.world.entity.animal.Salmon;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;
import java.util.List;

public final class PipGoals {

    /** Normal behaviour: trail the owner. */
    public static class FollowGoal extends Goal {
        private final PipEntity pip; private int timer;
        public FollowGoal(PipEntity pip) { this.pip = pip; setFlags(EnumSet.of(Flag.MOVE)); }
        @Override public boolean canUse() { return pip.getOrder() == PipEntity.Order.FOLLOW && !pip.isMonster() && pip.getOwner() != null; }
        @Override public void tick() {
            Player o = pip.getOwner(); if (o == null) return;
            if (--timer > 0) return; timer = 10;
            double d = pip.distanceToSqr(o);
            if (d > 400) pip.snapNear(o);
            else if (d > 9) pip.getNavigation().moveTo(o, 1.15);
            else pip.getNavigation().stop();
        }
    }

    public static class StayGoal extends Goal {
        private final PipEntity pip;
        public StayGoal(PipEntity pip) { this.pip = pip; setFlags(EnumSet.of(Flag.MOVE)); }
        @Override public boolean canUse() { return pip.getOrder() == PipEntity.Order.STAY && !pip.isMonster(); }
        @Override public void tick() { pip.getNavigation().stop(); }
    }

    /** "Pip, gather wood" / "Pip, get me a fish". */
    public static class GatherGoal extends Goal {
        private final PipEntity pip;
        private BlockPos log; private AbstractFish fish; private Item item = Items.OAK_LOG;
        private int count, timer, repath; private boolean returning;

        public GatherGoal(PipEntity pip) { this.pip = pip; setFlags(EnumSet.of(Flag.MOVE)); }
        @Override public boolean canUse() {
            PipEntity.Order o = pip.getOrder();
            return (o == PipEntity.Order.WOOD || o == PipEntity.Order.FISH) && !pip.isMonster() && pip.getOwner() != null;
        }
        @Override public void start() { returning = false; count = 0; timer = 1200; log = null; fish = null; repath = 0; }
        @Override public void stop() { pip.getNavigation().stop(); }

        private void goTo(Vec3 p) { if (--repath <= 0) { repath = 10; pip.getNavigation().moveTo(p.x, p.y, p.z, 1.2); } }
        private void fail(Player owner) {
            if (owner instanceof ServerPlayer sp) sp.displayClientMessage(Component.literal("Pip couldn't find any."), true);
            pip.setOrder(PipEntity.Order.FOLLOW);
        }

        private void find() {
            Level w = pip.level(); BlockPos o = pip.blockPosition(); log = null; fish = null;
            if (pip.getOrder() == PipEntity.Order.WOOD) {
                double best = Double.MAX_VALUE;
                for (BlockPos p : BlockPos.betweenClosed(o.offset(-20, -6, -20), o.offset(20, 10, 20))) {
                    if (w.getBlockState(p).is(BlockTags.LOGS)) {
                        double d = p.distSqr(o);
                        if (d < best) { best = d; log = p.immutable(); }
                    }
                }
            } else {
                List<AbstractFish> list = w.getEntitiesOfClass(AbstractFish.class, pip.getBoundingBox().inflate(24),
                        f -> f instanceof Cod || f instanceof Salmon);
                double best = Double.MAX_VALUE;
                for (AbstractFish f : list) { double d = pip.distanceToSqr(f); if (d < best) { best = d; fish = f; } }
            }
        }

        @Override public void tick() {
            Player owner = pip.getOwner(); if (owner == null) return;
            if (--timer <= 0) { pip.setOrder(PipEntity.Order.FOLLOW); return; }

            if (returning) {
                goTo(owner.position());
                if (pip.distanceToSqr(owner) < 6.25) {
                    pip.spawnAtLocation(new ItemStack(item, count));
                    pip.playSound(SoundEvents.CAT_PURREOW, 1f, 1f);
                    pip.setOrder(PipEntity.Order.FOLLOW);
                }
                return;
            }

            if (pip.getOrder() == PipEntity.Order.WOOD) {
                Level w = pip.level();
                if (log == null || !w.getBlockState(log).is(BlockTags.LOGS)) { find(); if (log == null) { fail(owner); return; } }
                Vec3 c = Vec3.atCenterOf(log);
                if (pip.distanceToSqr(c) < 6.25) {
                    BlockPos p = log;
                    while (w.getBlockState(p).is(BlockTags.LOGS) && count < 8) {
                        item = w.getBlockState(p).getBlock().asItem();
                        w.destroyBlock(p, false, pip); count++; p = p.above();
                    }
                    returning = count > 0;
                } else goTo(c);
            } else {
                if (fish == null || !fish.isAlive()) { find(); if (fish == null) { fail(owner); return; } }
                if (pip.distanceToSqr(fish) < 9.0) {
                    item = fish instanceof Salmon ? Items.SALMON : Items.COD;
                    count = 1; fish.discard(); returning = true;
                } else goTo(fish.position());
            }
        }
    }

    /** Monster form: always staring. Creeps closer whenever you look away, freezes when you look at it. */
    public static class HauntGoal extends Goal {
        private final PipEntity pip; private int repath;
        public HauntGoal(PipEntity pip) { this.pip = pip; setFlags(EnumSet.of(Flag.MOVE)); }
        @Override public boolean canUse() { return pip.isMonster() && pip.getOwner() != null; }

        private boolean watched(Player o) {
            Vec3 look = o.getViewVector(1f);
            Vec3 to = pip.getEyePosition().subtract(o.getEyePosition()).normalize();
            return look.dot(to) > 0.5 && o.hasLineOfSight(pip);
        }

        @Override public void tick() {
            Player o = pip.getOwner(); if (o == null) return;
            pip.lookAtOwner(o);
            double d = pip.distanceTo(o);
            if (d > 48) { pip.snapNear(o); return; }
            if (watched(o)) {
                pip.getNavigation().stop();
                pip.setDeltaMovement(0, pip.getDeltaMovement().y, 0);
            } else if (d > 5) {
                if (--repath <= 0) { repath = 5; pip.getNavigation().moveTo(o, 1.5); }
            } else pip.getNavigation().stop();
        }
    }
}
