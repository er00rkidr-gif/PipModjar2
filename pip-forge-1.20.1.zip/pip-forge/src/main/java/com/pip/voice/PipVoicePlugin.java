package com.pip.voice;

import com.mojang.logging.LogUtils;
import com.pip.PipCommands;
import de.maxhenkel.voicechat.api.ForgeVoicechatPlugin;
import de.maxhenkel.voicechat.api.VoicechatApi;
import de.maxhenkel.voicechat.api.VoicechatConnection;
import de.maxhenkel.voicechat.api.VoicechatPlugin;
import de.maxhenkel.voicechat.api.events.EventRegistration;
import de.maxhenkel.voicechat.api.events.MicrophonePacketEvent;
import de.maxhenkel.voicechat.api.opus.OpusDecoder;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.fml.loading.FMLPaths;
import org.slf4j.Logger;
import org.vosk.LibVosk;
import org.vosk.LogLevel;
import org.vosk.Model;
import org.vosk.Recognizer;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Simple Voice Chat plugin: decodes each player's mic, runs offline speech-to-text (Vosk),
 * and feeds the text into the same parser as typed chat ("Pip, gather some wood").
 * Needs a Vosk model unzipped into  config/pip/vosk-model/
 */
@ForgeVoicechatPlugin
public class PipVoicePlugin implements VoicechatPlugin {
    private static final Logger LOG = LogUtils.getLogger();
    private static final Pattern TEXT = Pattern.compile("\"text\"\\s*:\\s*\"([^\"]*)\"");

    private VoicechatApi api;
    private Model model;
    private final Map<UUID, OpusDecoder> decoders = new ConcurrentHashMap<>();
    private final Map<UUID, Recognizer> recognizers = new ConcurrentHashMap<>();
    private final ExecutorService exec = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "pip-stt"); t.setDaemon(true); return t;
    });

    @Override public String getPluginId() { return "pip"; }

    @Override
    public void initialize(VoicechatApi api) {
        this.api = api;
        Path dir = FMLPaths.CONFIGDIR.get().resolve("pip").resolve("vosk-model");
        if (!Files.isDirectory(dir)) {
            LOG.warn("No Vosk model found at {} - voice commands disabled (typed 'Pip, ...' still works).", dir);
            return;
        }
        try {
            LibVosk.setLogLevel(LogLevel.WARNINGS);
            model = new Model(dir.toString());
            LOG.info("Pip is listening.");
        } catch (Throwable e) {
            LOG.error("Could not load Vosk model", e);
        }
    }

    @Override
    public void registerEvents(EventRegistration reg) {
        reg.registerEvent(MicrophonePacketEvent.class, this::onMic);
    }

    private void onMic(MicrophonePacketEvent e) {
        if (model == null) return;
        VoicechatConnection con = e.getSenderConnection();
        if (con == null || !(con.getPlayer().getPlayer() instanceof ServerPlayer sp)) return;
        byte[] opus = e.getPacket().getOpusEncodedData();
        exec.execute(() -> process(sp, opus));
    }

    private void process(ServerPlayer sp, byte[] opus) {
        try {
            UUID id = sp.getUUID();
            OpusDecoder dec = decoders.computeIfAbsent(id, k -> api.createDecoder());
            Recognizer rec = recognizers.get(id);
            if (rec == null) { rec = new Recognizer(model, 16000f); recognizers.put(id, rec); }

            if (opus == null || opus.length == 0) {          // player stopped talking
                dec.resetState();
                deliver(sp, extract(rec.getFinalResult()));
                return;
            }
            short[] pcm = dec.decode(opus);                    // 48 kHz mono
            short[] ds = new short[pcm.length / 3];            // naive downsample to 16 kHz
            for (int i = 0; i < ds.length; i++) ds[i] = (short) ((pcm[3 * i] + pcm[3 * i + 1] + pcm[3 * i + 2]) / 3);
            if (rec.acceptWaveForm(ds, ds.length)) deliver(sp, extract(rec.getResult()));
        } catch (Throwable ex) {
            LOG.error("Voice processing failed", ex);
        }
    }

    private static String extract(String json) {
        Matcher m = TEXT.matcher(json);
        return m.find() ? m.group(1) : "";
    }

    private void deliver(ServerPlayer sp, String text) {
        if (text == null || text.isBlank()) return;
        sp.getServer().execute(() -> PipCommands.handle(sp, text));
    }
}
