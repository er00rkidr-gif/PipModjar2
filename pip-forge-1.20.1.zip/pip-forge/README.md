# Pip - Forge 1.20.1 port

- Spawn Pip with the Pip Spawn Egg (creative > spawn eggs), right-click with raw cod/salmon to tame.
- Orders (chat or Simple Voice Chat): "Pip, gather some wood" / "Pip, get me a fish" / "Pip, stay" / "Pip, follow me".
  Empty-hand right-click toggles sit/follow.
- Nights since taming: 2 = stares + glowing eyes, 3-4 = head tilt + ignores ~40% of orders,
  5 = monster form (ignores every order, always staring, creeps closer when you look away).
  Tune in PipEntity.java (UNEASY_NIGHT / DISOBEY_NIGHT / MONSTER_NIGHT).
- Voice: install Simple Voice Chat (Forge 1.20.1), download vosk-model-small-en-us-0.15 and unzip it into
  config/pip/vosk-model/ (so that config/pip/vosk-model/am and /conf exist). No model = typed chat only.
- Build: see build.gradle.ADD-THESE-LINES.txt
